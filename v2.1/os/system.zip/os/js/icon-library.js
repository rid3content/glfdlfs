/**
 * RID3 Icon Library — набор встроенных SVG-иконок для приложений.
 *
 * Каждая иконка — самостоятельный <svg> (viewBox 0 0 24 24, обводка
 * currentColor), поэтому автоматически подхватывает акцентный цвет /
 * тему интерфейса без дополнительной настройки.
 *
 * Использование иконки из библиотеки в конфиге приложения (.rva или
 * config.rnn): значение поля icon вида "svg:<key>", например:
 *   icon: svg:calculator
 * RID3Icon.html() распознаёт такой префикс и рендерит нужный SVG
 * (см. js/icon.js). Если ключ неизвестен — используется иконка "app"
 * как безопасный фолбэк.
 */
const RID3IconLibrary = (() => {
  const S = 'fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"';
  const svg = (label, body) => `<svg viewBox="0 0 24 24" ${S} role="img" aria-label="${label}">${body}</svg>`;

  const ICONS = {
    app: svg('Приложение', '<rect x="4" y="4" width="7" height="7" rx="1.5"/><rect x="13" y="4" width="7" height="7" rx="1.5"/><rect x="4" y="13" width="7" height="7" rx="1.5"/><rect x="13" y="13" width="7" height="7" rx="1.5"/>'),
    calculator: svg('Калькулятор', '<rect x="5" y="3" width="14" height="18" rx="2"/><line x1="8" y1="7" x2="16" y2="7"/><circle cx="8" cy="12" r=".9" fill="currentColor" stroke="none"/><circle cx="12" cy="12" r=".9" fill="currentColor" stroke="none"/><circle cx="16" cy="12" r=".9" fill="currentColor" stroke="none"/><circle cx="8" cy="16" r=".9" fill="currentColor" stroke="none"/><circle cx="12" cy="16" r=".9" fill="currentColor" stroke="none"/><circle cx="16" cy="16" r=".9" fill="currentColor" stroke="none"/>'),
    notes: svg('Заметки', '<path d="M7 3h8l4 4v13a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1Z"/><path d="M15 3v4h4"/><line x1="8" y1="12" x2="15" y2="12"/><line x1="8" y1="16" x2="13" y2="16"/>'),
    files: svg('Файлы', '<path d="M3 8a1 1 0 0 1 1-1h5l2 2h9a1 1 0 0 1 1 1v8a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1Z"/>'),
    folder: svg('Папка', '<path d="M3 7a1 1 0 0 1 1-1h5l2 2h9a1 1 0 0 1 1 1v9a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1Z"/>'),
    settings: svg('Настройки', '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .34 1.87l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.7 1.7 0 0 0-1.87-.34 1.7 1.7 0 0 0-1.04 1.56V21a2 2 0 1 1-4 0v-.09A1.7 1.7 0 0 0 8.96 19a1.7 1.7 0 0 0-1.87.34l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.7 1.7 0 0 0 4.6 15a1.7 1.7 0 0 0-1.56-1.04H3a2 2 0 1 1 0-4h.09A1.7 1.7 0 0 0 4.6 8.96a1.7 1.7 0 0 0-.34-1.87l-.06-.06A2 2 0 1 1 7.03 4.2l.06.06a1.7 1.7 0 0 0 1.87.34H9a1.7 1.7 0 0 0 1.04-1.56V3a2 2 0 1 1 4 0v.09c0 .68.4 1.29 1.04 1.56h0a1.7 1.7 0 0 0 1.87-.34l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.7 1.7 0 0 0-.34 1.87V9c.27.64.88 1.04 1.56 1.04H21a2 2 0 1 1 0 4h-.09A1.7 1.7 0 0 0 19.4 15Z"/>'),
    code: svg('Код', '<polyline points="9 8 4 12 9 16"/><polyline points="15 8 20 12 15 16"/><line x1="13.5" y1="5" x2="10.5" y2="19"/>'),
    terminal: svg('Терминал', '<rect x="3" y="4" width="18" height="16" rx="2"/><polyline points="7 9 11 12.5 7 16"/><line x1="12" y1="16" x2="17" y2="16"/>'),
    browser: svg('Браузер', '<circle cx="12" cy="12" r="9"/><line x1="3" y1="12" x2="21" y2="12"/><path d="M12 3c2.5 2.6 3.8 5.7 3.8 9s-1.3 6.4-3.8 9c-2.5-2.6-3.8-5.7-3.8-9s1.3-6.4 3.8-9Z"/>'),
    mail: svg('Почта', '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3.5 6.5 12 13l8.5-6.5"/>'),
    chat: svg('Чат', '<path d="M4 5h16a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H9l-5 4v-4H4a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1Z"/>'),
    calendar: svg('Календарь', '<rect x="3" y="5" width="18" height="16" rx="2"/><line x1="16" y1="3" x2="16" y2="7"/><line x1="8" y1="3" x2="8" y2="7"/><line x1="3" y1="10" x2="21" y2="10"/>'),
    clock: svg('Часы', '<circle cx="12" cy="12" r="9"/><polyline points="12 7 12 12 15.5 14"/>'),
    image: svg('Изображение', '<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="2"/><path d="M21 17.5 15 12l-5.5 5.5L7 15l-4 4"/>'),
    music: svg('Музыка', '<path d="M9 18V5.5L20 4v12.5"/><circle cx="6" cy="18" r="3"/><circle cx="17" cy="16.5" r="3"/>'),
    video: svg('Видео', '<rect x="3" y="5" width="14" height="14" rx="2"/><path d="M17 9.5 21.5 7v10L17 14.5"/>'),
    camera: svg('Камера', '<path d="M4 8h3l1.5-2.5h7L17 8h3a1 1 0 0 1 1 1v9a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V9a1 1 0 0 1 1-1Z"/><circle cx="12" cy="13.5" r="3.5"/>'),
    chart: svg('Графики', '<line x1="4" y1="20" x2="4" y2="10"/><line x1="10" y1="20" x2="10" y2="4"/><line x1="16" y1="20" x2="16" y2="13"/><line x1="22" y1="20" x2="22" y2="7"/><line x1="2" y1="20" x2="22" y2="20"/>'),
    lock: svg('Безопасность', '<rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>'),
    cloud: svg('Облако', '<path d="M7 18a4.5 4.5 0 0 1-1-8.9 5.5 5.5 0 0 1 10.7-1.9A4 4 0 0 1 17 18H7Z"/>'),
    heart: svg('Избранное', '<path d="M12 20.5s-7.5-4.6-9.8-9.1C.6 8 2 4.7 5.2 4c2-.5 3.9.3 5.3 2.1a1 1 0 0 0 1.6 0C13.4 4.3 15.3 3.5 17.3 4c3.2.7 4.6 4 3 7.4-2.3 4.5-8.3 9.1-8.3 9.1Z"/>'),
    star: svg('Отмечено', '<polygon points="12 2.5 15 9 22 10 17 15 18.2 21.5 12 18.3 5.8 21.5 7 15 2 10 9 9"/>'),
    cart: svg('Магазин', '<circle cx="9" cy="20" r="1.4"/><circle cx="18" cy="20" r="1.4"/><path d="M2.5 3h2.5l2.7 12.2a2 2 0 0 0 2 1.6h8.1a2 2 0 0 0 2-1.6L21.5 8H6.2"/>'),
    phone: svg('Телефон', '<path d="M6.5 3h3l1.3 5-2.3 1.6a13 13 0 0 0 5.9 5.9L16 13.2l5 1.3v3a2 2 0 0 1-2.2 2C11 19.2 4.8 13 4.5 5.2A2 2 0 0 1 6.5 3Z"/>'),
    map: svg('Карта', '<polygon points="9 4 3 6.5 3 20 9 17.5 15 20 21 17.5 21 4 15 6.5 9 4"/><line x1="9" y1="4" x2="9" y2="17.5"/><line x1="15" y1="6.5" x2="15" y2="20"/>'),
    book: svg('Книга', '<path d="M4 5.5A2.5 2.5 0 0 1 6.5 3H20v16H6.5A2.5 2.5 0 0 0 4 21.5Z"/><line x1="4" y1="19" x2="20" y2="19"/>'),
    trash: svg('Корзина', '<polyline points="4 7 20 7"/><path d="M6 7v13a1 1 0 0 0 1 1h10a1 1 0 0 0 1-1V7"/><path d="M9 7V4.5A1.5 1.5 0 0 1 10.5 3h3A1.5 1.5 0 0 1 15 4.5V7"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/>'),
    download: svg('Скачать', '<path d="M12 3v12"/><polyline points="7 10 12 15 17 10"/><line x1="4" y1="20" x2="20" y2="20"/>'),
    upload: svg('Загрузить', '<path d="M12 21V9"/><polyline points="7 14 12 9 17 14"/><line x1="4" y1="4" x2="20" y2="4"/>'),
    link: svg('Ссылка', '<path d="M9.5 14.5 14.5 9.5"/><path d="M11 6.5 12.5 5A4 4 0 1 1 18 10.5L16.5 12"/><path d="M13 17.5 11.5 19A4 4 0 1 1 6 13.5L7.5 12"/>'),
    wifi: svg('Сеть', '<path d="M2 9a15.5 15.5 0 0 1 20 0"/><path d="M5.5 12.8a10.8 10.8 0 0 1 13 0"/><path d="M9 16.6a5.8 5.8 0 0 1 6 0"/><circle cx="12" cy="20" r="1" fill="currentColor" stroke="none"/>'),
    battery: svg('Батарея', '<rect x="2" y="8" width="17" height="9" rx="2"/><line x1="21" y1="11" x2="21" y2="14"/><rect x="5" y="10.5" width="8" height="4" fill="currentColor" stroke="none"/>'),
    power: svg('Питание', '<line x1="12" y1="3" x2="12" y2="11"/><path d="M7 6a8 8 0 1 0 10 0"/>'),
    user: svg('Профиль', '<circle cx="12" cy="8" r="4"/><path d="M4 20c1.3-4 4.5-6 8-6s6.7 2 8 6"/>'),
    home: svg('Домашняя', '<path d="M4 11 12 4l8 7"/><path d="M6 9.5V20h12V9.5"/>'),
    search: svg('Поиск', '<circle cx="11" cy="11" r="7"/><line x1="20" y1="20" x2="16.2" y2="16.2"/>'),
    palette: svg('Оформление', '<path d="M12 3a9 9 0 0 0 0 18c1.4 0 2-1 1.3-2.2-.4-.7 0-1.6.9-1.8H16a5 5 0 0 0 5-5 9 9 0 0 0-9-9Z"/><circle cx="7.5" cy="10.5" r="1" fill="currentColor" stroke="none"/><circle cx="10.5" cy="7" r="1" fill="currentColor" stroke="none"/><circle cx="15" cy="7.5" r="1" fill="currentColor" stroke="none"/>'),
    game: svg('Игра', '<rect x="2.5" y="8" width="19" height="10" rx="4"/><line x1="7" y1="11" x2="7" y2="15"/><line x1="5" y1="13" x2="9" y2="13"/><circle cx="16" cy="12" r="1" fill="currentColor" stroke="none"/><circle cx="18.5" cy="14.5" r="1" fill="currentColor" stroke="none"/>'),
    weather: svg('Погода', '<circle cx="8" cy="8" r="3.5"/><path d="M12.5 15a3.8 3.8 0 0 0-1-7.4 5.5 5.5 0 0 0-10.2 2 4 4 0 0 0 .7 8h9.5a3 3 0 0 0 1-.6Z"/>'),
    printer: svg('Печать', '<path d="M7 8V3.5h10V8"/><rect x="3.5" y="8" width="17" height="8" rx="1.5"/><path d="M7 14.5h10V20.5H7Z"/>'),
    wave: svg('Приветствие', '<path d="M9 12.5V6a1.5 1.5 0 0 1 3 0v5"/><path d="M12 11V4.5a1.5 1.5 0 0 1 3 0V11"/><path d="M15 11.5V6.5a1.5 1.5 0 0 1 3 0v8c0 3.6-2.4 6-6 6h-1c-2.2 0-3.5-.7-4.8-2.4L3 13.8c-.6-.9-.3-1.9.6-2.3.8-.4 1.6-.1 2.2.6L8 15"/>'),
    server: svg('Сервер', '<rect x="3" y="4" width="18" height="6" rx="1.5"/><rect x="3" y="14" width="18" height="6" rx="1.5"/><circle cx="7" cy="7" r=".8" fill="currentColor" stroke="none"/><circle cx="7" cy="17" r=".8" fill="currentColor" stroke="none"/>'),
    warning: svg('Предупреждение', '<path d="M12 3.5 21.5 20h-19Z"/><line x1="12" y1="9.5" x2="12" y2="14"/><circle cx="12" cy="17" r=".9" fill="currentColor" stroke="none"/>'),
  };

  /** Список для UI-пикера: [{ key, label, svg }] в стабильном порядке. */
  function list() {
    return Object.keys(ICONS).map((key) => ({ key, svg: ICONS[key] }));
  }

  function get(key) {
    return ICONS[key] || ICONS.app;
  }

  function has(key) {
    return Object.prototype.hasOwnProperty.call(ICONS, key);
  }

  return { get, has, list, KEYS: Object.keys(ICONS) };
})();
